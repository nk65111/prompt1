package com.transform.Pdf;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

import com.pdf.conversion.PdfConversion;

public class App {
    private static final String url = "jdbc:jtds:sqlserver://127.0.0.1;instance=SQLEXPRESS;DatabaseName=master";
    private static final String driver = "net.sourceforge.jtds.jdbc.Driver";
    private static final String userName = "user";
    private static final String password = "password";
    
    private static final int batchSize = 100; 
    private static final int threadCount = 4; 

    public static void main(String[] args) {
        try {
            Class.forName(driver);
            Connection connection = DriverManager.getConnection(url, userName, password);

            String query = "SELECT file_content, file_name, file_size FROM files_table"; // Adjust this query according to your database schema
            PreparedStatement statement = connection.prepareStatement(query, ResultSet.TYPE_FORWARD_ONLY, ResultSet.CONCUR_READ_ONLY);
            statement.setFetchSize(batchSize);

            ResultSet resultSet = statement.executeQuery();

            ExecutorService executor = Executors.newFixedThreadPool(threadCount);

            while (resultSet.next()) {
                String fileContent = resultSet.getString("file_content");
                String fileName = resultSet.getString("file_name");
                long fileSize = resultSet.getLong("file_size");
                
                executor.submit(new FileProcessorTask(fileContent, fileName, fileSize));
            }

            executor.shutdown();
            while (!executor.isTerminated()) {
                // Wait for all tasks to complete
            }

            resultSet.close();
            statement.close();
            connection.close();
        } catch (ClassNotFoundException | SQLException e) {
            e.printStackTrace();
        }
    }

    static class FileProcessorTask implements Runnable {
        private final String fileContent;
        private final String fileName;
        private final long fileSize;

        public FileProcessorTask(String fileContent, String fileName, long fileSize) {
            this.fileContent = fileContent;
            this.fileName = fileName;
            this.fileSize = fileSize;
        }

        @Override
        public void run() {
          
            PdfConversion.changeFormat(fileContent, fileContent, fileContent, fileContent, fileContent, fileContent, fileContent, fileName, fileContent);
            System.out.println("Processed file content: " + fileContent);
            System.out.println("File Name: " + fileName);
            System.out.println("File Size: " + fileSize);
           
        }
    }
}

